# Round 6

This directory contains the prices and anonymized trades data that was used during submission runs. Round 6 day X represents the submission data of round X, where X = 0 means the tutorial round. The anonymized trades data is derived from the submission of an algorithm that places no orders.
