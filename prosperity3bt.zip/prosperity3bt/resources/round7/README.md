# Round 7

This directory contains the prices data that was used during end-of-round runs. Round 7 day X represents the submission data of round X. The exception to the rule is round 1, its old end-of-round data can be found in round 7 day 0 while its new data will be made available at round 7 day 1 once its made available.
